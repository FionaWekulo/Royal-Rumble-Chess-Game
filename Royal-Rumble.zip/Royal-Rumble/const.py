# Screen dimensions
WIDTH = 720
HEIGHT = 720

# Board dimensions
ROWS = 8
COLS = 8
SQSIZE = WIDTH // COLS